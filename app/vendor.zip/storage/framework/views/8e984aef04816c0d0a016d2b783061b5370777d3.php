
<?php $__env->startSection('title', 'Liste des usagers'); ?>
<?php $__env->startSection('content'); ?>
    <div>
        <div class="auth__header">
            <h1 class="auth_header_u-list-title">Liste des usagers</h1>
        </div>

        <div class="auth_user-list">
            <table>
                <thead>
                    <tr>
                        <th class="auth_user-list_th">Id</th>
                        <th class="auth_user-list_th">Nom</th>
                        <th class="auth_user-list_th">Prénom</th>
                        <th class="auth_user-list_th"></th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Affiche les utilisateurs -->
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="auth_user-list_td"><?php echo e($user->id); ?></td>
                            <td class="auth_user-list_td"><?php echo e($user->nom); ?></td>
                            <td class="auth_user-list_td"><?php echo e($user->prenom); ?></td>
                            <td class="auth_user-list_td">
                            <form action="<?php echo e(route('user.delete', $user->id)); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                                <input class="auth_user-list_btn" type="submit" value="supprimer">
                            </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <td class="auth_user-list_td" colspan="4">Aucun usagé disponible</td>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jacky\Documents\Projet vino\vino\app\resources\views/auth/admin-user-list.blade.php ENDPATH**/ ?>