
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="mx-5 mt-5">
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php if(session('success')): ?>
                <div class="alert alert-success">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

                <div class="modifier text-center ">
                    <h3>Mes Celliers</h3>
                </div>

            <form action="<?php echo e(route('cellier.update', $cellier->id)); ?>" method="POST">
                <?php echo method_field('PUT'); ?>
                <?php echo csrf_field(); ?>
                <div class="form-group mb-3">
                    <label for="nomDuCellier" class="mb-0">NOM DU CELLIER:</label>
                    <input placeholder="EX: MAISON" type="text" class="form-control mt-1" id="nom" name="nom" value="<?php echo e(old('nom', $cellier->nom)); ?>">
                </div>

                <div class="d-flex justify-content-between">
                    <button type="submit" class="btn-submit">MODIFIER CELLIER</button>
                </div>
            </form>

               

            <form action="<?php echo e(route('cellier.destroy', $cellier->id)); ?>" method="POST">
                <?php echo method_field('DELETE'); ?>
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn-submit">SUPPRIMER CELLIER</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jacky\Documents\Projet vino\vino\app\resources\views/cellier/show.blade.php ENDPATH**/ ?>