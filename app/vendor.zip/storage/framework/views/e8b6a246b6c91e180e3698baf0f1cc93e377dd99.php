<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <title>Recherche</title>

</head>
<body>
    <div class="body__container">
        <div class="auth__header">
            <h1>Recherche</h1>
        </div>
        <div>
            <div class="auth__col">
                <?php $__currentLoopData = $bouteilles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bouteille): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="recherche__container">
                        <div class="img__container">
                            <img src="<?php echo e($bouteille->url_img); ?>" class="recherche__img">
                        </div>
                        <div class="bouteille__info">
                            <p class="bouteille__nom"><?php echo e($bouteille->nom); ?></p>
                            <p class="bouteille__color"><?php echo e($bouteille->pays); ?> | <?php echo e($bouteille->type_id); ?> | <?php echo e($bouteille->format); ?></p>
                            <p class="bouteille__prix"><?php echo e($bouteille->prix_saq); ?> $</p>
                            <p><a class="bouteille__lien" href="<?php echo e($bouteille->url_saq); ?>">voir plus</a></p>
                        </div>
                    </div>   
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</body>
<footer class="footer">
    <img src="/icons/home.png" class="footer-icon"/>
    <img src="/icons/moncellier.png" class="footer-icon"/>
    <img src="/icons/rechercher.png" class="footer-icon"/>
    <img src="/icons/profil.png" class="footer-icon"/>
</footer>
</html>
<?php /**PATH C:\Users\Jacky\Documents\Projet vino\vino\app\resources\views/bouteille/index.blade.php ENDPATH**/ ?>