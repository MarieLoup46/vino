
<?php $__env->startSection('content'); ?>
    <div class="cellier-row">
        <div class="cellier-main-content">
            <div class="cellier-title-section">
                <h3 class="cellier-title">Mes celliers</h3>
                <div class="cellier-button-section">
                    <a href="<?php echo e(route('cellier.create')); ?>" class="cellier-add-button">AJOUTER UN CELLIER</a>
                </div>
            </div>

            <div class="cellier-list">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="cellier-item">
                        <div class="cellier-item-image">
                            <a href="<?php echo e(route('cellier.show', $item->id)); ?>">
                                <img alt="<?php echo e($item->nom); ?>" src="<?php echo e(asset('icons/' . $item->icon)); ?>" class="cellier-icon" />
                            </a>
                        </div>
                        <div class="cellier-item-info">
                            <span class="cellier-name"><?php echo e($item->nom); ?></span>
                            <small class="cellier-bottle-count"><?php echo e($index); ?> Bouteille</small>
                        </div>
                        <div class="cellier-item-action">
                            <a href="<?php echo e(route('cellier.show', $item->id)); ?>">
                                <img src="<?php echo e(asset('icons/info.png')); ?>" alt="info" class="cellier-info-icon" />
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jacky\Documents\Projet vino\vino\app\resources\views/cellier/index.blade.php ENDPATH**/ ?>