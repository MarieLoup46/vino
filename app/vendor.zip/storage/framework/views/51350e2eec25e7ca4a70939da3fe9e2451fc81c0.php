<?php $__env->startSection('title', 'Accueil'); ?>
<?php $__env->startSection('content'); ?>

<div class="accueil__container">
    <div class="accueil__header">
        <h1 class="accueil__header-title">Bonjour <?php echo e(Auth::user() ? Auth::user()->prenom :
            'Guest'); ?></h1>
        <div class="accueil__header-button">
            <a href="/celliers">Ajouter un Cellier</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Jacky\Documents\Projet vino\vino\app\resources\views/auth/accueil.blade.php ENDPATH**/ ?>